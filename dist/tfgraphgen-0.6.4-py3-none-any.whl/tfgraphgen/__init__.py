from general_nn import GeneralNetworks
from rnn import RecurrentNetworks

__all__=['GeneralNetworks','RecurrentNetworks']
